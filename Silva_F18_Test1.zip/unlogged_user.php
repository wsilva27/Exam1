<?php 
    if(!isset($_SESSION))
        session_start();
    // Welbert Marques Silva
    // Web Programming - PHP
    // Fall 2018
    // Practical Test 1
?>

<html>
<head>
    <title>The PHP Store</title>
</head>
<body>
    <center>
    <h1>You are currently not logged into our system.</h1>
    <p>
        Once logged in, you will have access to your personal area<br />
        If you have already registered,         
        <a href="user_login.php">click here</a> to login,
        or if would like to create an account,
        <a href="register.php">click here</a> to register.
    </p>
    </center>
</body>
</html>
